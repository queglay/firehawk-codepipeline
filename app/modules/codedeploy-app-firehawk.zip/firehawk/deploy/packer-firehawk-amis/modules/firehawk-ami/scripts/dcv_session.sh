#!/bin/bash
sudo dcv create-session --owner ec2-user --user ec2-user my-session
