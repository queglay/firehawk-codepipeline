<h1 align="center">Sponsors &amp; Backers</h1>

OpenFirehawk is an open source project (MPL2.0).  It's developement is made possible by these incredible [backers](https://github.com/firehawkvfx/openfirehawk/blob/master/BACKERS.md). If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/openfirehawk)

### Backers

Harvey Fong  
Anthony Morrelle  
Michael Garrett  
Hunter Williams  
Mike Marcuzzi
### Previous Backers

Geordie Martinez
Chris Hönninger  
Seona Hwang  
Edward Twiss  
Sergio Caires  
Stan Shapetskiy  
Anton Ognyev  
Janghyung Kim  
Mikas Sadauskas  
Zach Judson  
Steven Quinones Colon  
Nuno Rivotti  

<!--stackedit_data:
eyJoaXN0b3J5IjpbNDk2NjgwMjc5LDQ3NzU4NzY0NiwtMTIwOT
M2MTI2MywtNTIzNzI5OTMwLC0xMTI3Mjg0MjUwLC0zNjA2NDcz
OTcsMTQyMTI4MzIyNywxNTU1NzM0NzA1LDEzNjg1NzE0OTUsOT
c3MDgzODA1LDE0NTQwMjA4MDJdfQ==
-->